class AppAssets {
  static String icBody = "assets/icons/ic_body.png",
      icEar = "assets/icons/ic_ear.png",
      icEye = "assets/icons/ic_eye.png",
      icHeart = "assets/icons/ic_heart.png",
      icKidney = "assets/icons/ic_kidney.png",
      icLiver = "assets/icons/ic_liver.png",
      icLungs = "assets/icons/ic_lungs.png",
      icStomach = "assets/icons/ic_stomach.png",
      icTooth = "assets/icons/ic_tooth.png",
      icLogin = "assets/images/img_login.png",
      imgSignup = "assets/images/signupBG.png",
      imgWelcome = "assets/images/img_welcome.png",
      imgDoctor = "assets/images/imgscreen2.png";
}
