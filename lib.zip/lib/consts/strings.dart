
class AppStrings {
  static String appname = "FYS",
      bestDocapp = "Best Doctor\n Appointment App",
      welcomeBack = "Welcome Back!",
      weAreExcited = "We're excited to have you back!",
      signupNow =
          "Sign up now and start explering all that our app has to offer.",
      email = "Email",
      emailHint = "Enter your email here",
      password = "Password",
      passwordHint = "Enter your password here",
      fullname = "Full name",
      fullnameHint = "Enter your name here",
      confirmPassword = "Confirm Password",
      phone = "Phone",
      forgetPassword = "Forget Password?",
      login = "Login",
      signup = "Create Now",
      alreadyHaveAccount = "Already have an account?",
      dontHaveAccount = "Don't have an account?",
      body = "Body",
      ear = "Ear",
      heart = "Heart",
      kidney = "Kidney",
      liver = "Liver",
      lungs = "Lungs",
      changePassword = "Change Password",
      termsCondition = "Terms & Conditions",
      signout = "Signout";

}


