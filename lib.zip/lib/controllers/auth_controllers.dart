import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/views/doctor_views/doctor_home_view.dart';
import 'package:emart_app/views/home_view/doctor_home_view.dart';
import 'package:emart_app/views/home_view/home.dart';
import 'package:emart_app/views/login_view/login_view.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class AuthController extends GetxController {
  var fullnameController = TextEditingController();
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  UserCredential? userCredential;

  var aboutController = TextEditingController();
  var servicesController = TextEditingController();
  var phoneController = TextEditingController();
  var timingController = TextEditingController();
  var categoryController = TextEditingController();
  var addressController = TextEditingController();

  isUserAlreadyLoggedIn() async {
    FirebaseAuth.instance.authStateChanges().listen((User? user) async {
      if (user != null) {
        var data = await FirebaseFirestore.instance
            .collection('doctors')
            .doc(user.uid)
            .get();
        var isDoc = data.data()?.containsKey('docName') ?? false;
        if (isDoc) {
          Get.offAll(() => Home(
                isDoctor: isDoc,
              ));
        } else {
          Get.offAll(() => Home(
                isDoctor: isDoc,
              ));
        }
      } else {
        Get.offAll(() => const LoginView());
      }
    });
  }

  loginUser() async {
    userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
  }

  signupUser(bool isDoctor) async {
    userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailController.text, password: passwordController.text);
    if (userCredential != null) {
      await storeUserData(userCredential!.user!.uid, fullnameController.text,
          emailController.text, isDoctor);
    }
  }

  storeUserData(
      String uid, String fullname, String email, bool isDoctor) async {
    var store = FirebaseFirestore.instance
        .collection(isDoctor ? 'doctors' : 'user')
        .doc(uid);
    if (isDoctor) {
      await store.set({
        'docid': FirebaseAuth.instance.currentUser?.uid,
        'docEmail': email,
        'docName': fullname,
        'docAbout': aboutController.text,
        'docAddress': addressController.text,
        'docServices': servicesController.text,
        'docTiming': timingController.text,
        'docPhone': phoneController.text,
        'docCategory': categoryController.text,
        'docRating': 1,
        'docPassword': passwordController.text
      });
    } else {
      await store.set({
        'fullname': fullname,
        'email': email,
        'password': passwordController.text,
        'userID': FirebaseAuth.instance.currentUser?.uid,
      });
    }
  }

  signout() async {
    await FirebaseAuth.instance.signOut();
  }
}
