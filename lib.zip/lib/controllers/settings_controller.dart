import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class SettingsController extends GetxController {
  @override
  void onInit() {
    getData = getUserData();
    getDoctorData(); // Call function to get doctor data
    super.onInit();
  }

  var isLoading = false.obs;
  var currentUser = FirebaseAuth.instance.currentUser;
  var username = ''.obs;
  var email = ''.obs;
  var doctorName = ''.obs; // Observable for doctor's name
  Future? getData;

  getUserData() async {
    isLoading(false);
    DocumentSnapshot<Map<String, dynamic>> user = await FirebaseFirestore
        .instance
        .collection('user')
        .doc(currentUser!.uid)
        .get();
    var userData = user.data();
    username.value = userData!['fullname'] ?? "";
    email.value = currentUser!.email ?? '';
    isLoading(false);
  }

  // Function to fetch doctor's data
  getDoctorData() async {
    isLoading(true);
    DocumentSnapshot<Map<String, dynamic>> doctor = await FirebaseFirestore
        .instance
        .collection('doctors')
        .doc(currentUser!
            .uid) // Assuming the doctor's UID is the same as the current user's UID
        .get();
    var doctorData = doctor.data();
    doctorName.value = doctorData!['docName'] ?? "";
    isLoading(false);
  }
}
