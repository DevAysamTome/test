import 'consts/consts.dart';

var iconList = [
  AppAssets.icBody,
  AppAssets.icEar,
  AppAssets.icHeart,
  AppAssets.icKidney,
  AppAssets.icLiver,
  AppAssets.icLungs,
];

var iconTitleList = [
  AppStrings.body,
  AppStrings.ear,
  AppStrings.heart,
  AppStrings.kidney,
  AppStrings.liver,
  AppStrings.lungs,
];

var settingsList = [
  AppStrings.changePassword,
  AppStrings.termsCondition,
  AppStrings.signout,
];

var settingsListIcons = [
  Icons.lock,
  Icons.note,
  Icons.logout,
];
