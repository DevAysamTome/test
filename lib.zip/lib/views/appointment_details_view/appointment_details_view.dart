import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emart_app/consts/consts.dart';

class AppointmentDetailsView extends StatelessWidget {
  final DocumentSnapshot doc;
  const AppointmentDetailsView({super.key, required this.doc});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AppStyle.bold(
            title: doc['appWithName'],
            color: Colors.white,
            size: AppSize.size18),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppStyle.bold(title: "Select Appointment Day"),
            5.heightBox,
            AppStyle.normal(title: doc['appDay']),
            10.heightBox,
            AppStyle.bold(title: "Select Appointment time"),
            5.heightBox,
            AppStyle.normal(title: doc['appTime']),
            20.heightBox,
            AppStyle.bold(title: "Mobile Number:"),
            5.heightBox,
            AppStyle.normal(title: doc['appMobile']),
            10.heightBox,
            AppStyle.bold(title: "Full name:"),
            5.heightBox,
            AppStyle.normal(title: doc['appName']),
            10.heightBox,
            AppStyle.bold(title: "Massege:"),
            5.heightBox,
            AppStyle.normal(title: doc['appMsg']),
          ],
        ),
      ),
    );
  }
}
