import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'dart:math' show atan2, cos, sin, sqrt;

class MapSection extends StatelessWidget {
  final LatLng currentLocation =
      LatLng(32.31037, 35.02863); // Example current location

  // Example location from database
  final LatLng locationFromDatabase = LatLng(32.41037, 35.02863);

  // Function to calculate distance between two LatLng points using Haversine formula
  double distanceBetween(LatLng point1, LatLng point2) {
    const double earthRadius = 6371; // Radius of the earth in km
    double lat1 = point1.latitude;
    double lon1 = point1.longitude;
    double lat2 = point2.latitude;
    double lon2 = point2.longitude;
    double dLat = _toRadians(lat2 - lat1);
    double dLon = _toRadians(lon2 - lon1);
    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRadians(lat1)) *
            cos(_toRadians(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double distance = earthRadius * c;
    return distance;
  }

  // Helper function to convert degrees to radians
  double _toRadians(double degree) {
    return degree * (pi / 180);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Map Section'),
      ),
      body: FlutterMap(
        options: MapOptions(
          center: currentLocation, // Center map on current location
          zoom: 13.0, // Initial map zoom level
        ),
        children: [
          // Use 'children' instead of 'layers'
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'dev.fleaflet.flutter_map.example',
          ),
          MarkerLayer(
            markers: [
              // Marker for current location
              Marker(
                point: currentLocation,
                width: 80,
                height: 80,
                builder: (BuildContext context) => Icon(
                  Icons.location_pin,
                  color: Colors.blue,
                ),
              ),
              // Marker for location from database
              Marker(
                point: locationFromDatabase,
                width: 80,
                height: 80,
                builder: (BuildContext context) => Icon(
                  Icons.location_pin,
                  color: Colors.red,
                ),
              ),
            ],
          ),
          // Polyline to show the distance between the two points
          PolylineLayer(
            polylines: [
              Polyline(
                points: [currentLocation, locationFromDatabase],
                color: Colors.green,
                strokeWidth: 2.0,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
