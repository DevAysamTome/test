
import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/lists.dart';
import 'package:emart_app/views/category_details_view/category_details_view.dart';
import 'package:get/get.dart';

class CategoryView extends StatelessWidget {
  const CategoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: AppStyle.normal(
            title: "Category", size: AppSize.size18, color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: GridView.builder(
          physics: const BouncingScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              mainAxisExtent: 170),
          itemCount: iconList.length,
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              onTap: () {
                Get.to(() => CategoryDetailsView(
                      catName: iconTitleList[index],
                    ));
              },
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.blue,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Image.asset(
                        iconList[index],
                        width: 60,
                        color: Colors.white,
                      ),
                    ),
                    30.heightBox,
                    AppStyle.bold(
                        title: iconTitleList[index],
                        color: Colors.white,
                        size: AppSize.size16),
                    10.heightBox,
                    AppStyle.normal(
                        title: "13 specialities",
                        color: Colors.white.withOpacity(0.5),
                        size: AppSize.size12),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
