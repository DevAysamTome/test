import 'package:emart_app/controllers/auth_controllers.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DoctorAppointmentScreen extends StatefulWidget {
  @override
  _DoctorAppointmentScreenState createState() =>
      _DoctorAppointmentScreenState();
}

class _DoctorAppointmentScreenState extends State<DoctorAppointmentScreen> {
  DateTime selectedDate = DateTime.now();
  List<String> selectedTimes = [];
  final List<String> timeSlots = [
    '09:00 AM',
    '09:30 AM',
    '10:00 AM',
    '10:30 AM',
    '12:00 PM',
    '12:30 PM',
    '01:00 PM',
    '01:30 PM',
    '02:00 PM',
    '03:00 PM',
    '03:30 PM',
    '04:30 PM',
    '05:00 PM',
    '05:30 PM',
  ];

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  String? doctorId = FirebaseAuth.instance.currentUser?.uid; // This should be dynamically set based on the logged-in doctor

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Appointments'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Date',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            ListTile(
              title: Text("${selectedDate.toLocal()}".split(' ')[0]),
              trailing: Icon(Icons.keyboard_arrow_down),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: selectedDate,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2030),
                );
                if (pickedDate != null && pickedDate != selectedDate)
                  setState(() {
                    selectedDate = pickedDate;
                  });
              },
            ),
            SizedBox(height: 20),
            Text(
              'Select Time Slots',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: timeSlots.map((time) {
                return ChoiceChip(
                  label: Text(time),
                  selected: selectedTimes.contains(time),
                  onSelected: (selected) {
                    setState(() {
                      if (selected) {
                        selectedTimes.add(time);
                      } else {
                        selectedTimes.remove(time);
                      }
                    });
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Save appointments to Firestore
                  _saveAppointments();
                },
                child: Text('Save Appointments'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveAppointments() async {
    // Convert date to a string
    String date =
        "${selectedDate.year}-${selectedDate.month}-${selectedDate.day}";

    // Prepare the data to be saved
    List<Map<String, dynamic>> appointments = selectedTimes.map((time) {
      return {
        'date': date,
        'time': time,
        'booked': false,
      };
    }).toList();

    // Save the data under the doctor's ID
    await _firestore
        .collection('doctors')
        .doc(doctorId)
        .collection('appointments')
        .doc(date)
        .set({
      'appointments_available': FieldValue.arrayUnion(appointments),
    }, SetOptions(merge: true));

    // Clear selections after saving
    setState(() {
      selectedTimes.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Appointments saved successfully')));
  }
}
