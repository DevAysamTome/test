import 'package:emart_app/views/doctor_views/header.dart';
import 'package:emart_app/views/doctor_views/home_doctor.dart';
import 'package:emart_app/views/doctor_views/pateintList.dart';
import 'package:emart_app/views/doctor_views/searchbar.dart';
import 'package:emart_app/views/doctor_views/upcomingappointments.dart';
import 'package:emart_app/views/settings_view/settings_view.dart';
import 'package:emart_app/views/user_appoinment_booked_views/user_booked_appointment.dart';
import 'package:flutter/material.dart';
import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/views/doctor_views/add_appointment_view.dart'; // Import the new screen

class DoctorHomeScreen extends StatefulWidget {
  @override
  State<DoctorHomeScreen> createState() => _DoctorHomeScreenState();
}

class _DoctorHomeScreenState extends State<DoctorHomeScreen> {
  int selectedIndex = 0;
  List screenList = [
    HomeDoctor(),
    const UserBookedAppointmentScreen(),
    const SettingsView(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: AppStyle.normal(title: "أهلا بك", color: Colors.white),
        backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        // Removed const keyword
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              20.heightBox,
              Header(),
              20.heightBox,
              const SearchBars(),
              20.heightBox, // Uncommented
              UpcomingAppointments(),
              20.heightBox, // Uncommented
              const SizedBox(height: 10),
              20.heightBox, // Uncommented
              PatientList(),
              20.heightBox, // Uncommented
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => DoctorAppointmentScreen()),
          );
        },
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add),
      ),
    );
  }
}
