import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/consts/images.dart';

class Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return  Row(
      children: <Widget>[
        CircleAvatar(
          radius: 30,
          backgroundImage:
              AssetImage(AppAssets.imgSignup), // Add a profile picture asset
        ),
        SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Welcome, Dr. Smith',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(
              'Have a nice day!',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
      ],
    );
  }
}
