import 'package:emart_app/consts/colors.dart';
import 'package:emart_app/views/doctor_views/doctor_home_view.dart';
import 'package:emart_app/views/settings_view/settings_view.dart';
import 'package:emart_app/views/user_appoinment_booked_views/user_booked_appointment.dart';
import 'package:flutter/material.dart';

class HomeDoctor extends StatefulWidget {
  const HomeDoctor({super.key});

  @override
  State<HomeDoctor> createState() => _HomeDoctorState();
}

class _HomeDoctorState extends State<HomeDoctor> {
  int selectedIndex = 0;
  List screenList = [
    DoctorHomeScreen(),
    UserBookedAppointmentScreen(),
    SettingsView(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screenList.elementAt(selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.primaryColor,
        type: BottomNavigationBarType.fixed,
        fixedColor: Colors.white,
        currentIndex: selectedIndex,
        onTap: (value) {
          setState(() {
            selectedIndex = value;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'الحجوزات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'الأعدادات',
          ),
        ],
      ),
    );
  }
}
