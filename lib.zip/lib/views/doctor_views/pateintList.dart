import 'package:flutter/material.dart';

class PatientList extends StatelessWidget {
  final List<String> patients = [
    'John Doe',
    'Jane Smith',
    'Robert Johnson',
    'Emily Davis',
    'Michael Brown',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Text(
          'Patients',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        ListView.builder(
          shrinkWrap:
              true, // Ensures the ListView takes up only the necessary space
          physics:
              NeverScrollableScrollPhysics(), // Prevents the ListView from scrolling independently
          itemCount: patients.length,
          itemBuilder: (context, index) {
            return ListTile(
              leading: CircleAvatar(
                child: Text(patients[index][0]),
              ),
              title: Text(patients[index]),
              subtitle: Text('Patient ID: ${1000 + index}'),
              trailing: const Icon(Icons.arrow_forward_ios),
            );
          },
        ),
      ],
    );
  }
}
