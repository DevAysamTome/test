import 'dart:developer';

import 'package:emart_app/consts/consts.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../../consts/images.dart';
import '../../controllers/home_controller.dart';
import '../../lists.dart';
import '../../res/components/custom_textfield.dart';
import '../category_details_view/category_details_view.dart';
import '../doctor_profile_view/doctor_profile_view.dart';

class DoctorHomeView extends StatefulWidget {
  @override
  _DoctorHomeViewState createState() => _DoctorHomeViewState();
}

class _DoctorHomeViewState extends State<DoctorHomeView> {
  List<String> _cities = [];
  List<String> _specializations = [];
  String? _selectedCity;
  String? _selectedSpecialization;

  final TextEditingController _searchQueryController = TextEditingController();
  final HomeController _controller = Get.put(HomeController());

  @override
  void initState() {
    super.initState();
    // Fetch cities and specializations from Firebase
    _fetchCities();
    _fetchSpecializations();
  }

  Future<void> _fetchCities() async {
    QuerySnapshot citySnapshot = await FirebaseFirestore.instance
        .collection('doctors')
        .get(); // Fetch data from 'doctors' collection
    Set<String> uniqueCities =
        Set<String>(); // Create a set to store unique city names
    citySnapshot.docs.forEach((doc) {
      // Iterate over each document in the snapshot
      uniqueCities
          .add(doc['docAddress'] as String); // Add the city name to the set
    });
    setState(() {
      _cities = uniqueCities.toList(); // Convert the set to a list
    });
  }

  Future<void> _fetchSpecializations() async {
    QuerySnapshot specializationSnapshot = await FirebaseFirestore.instance
        .collection('doctors')
        .get(); // Fetch data from 'doctors' collection
    Set<String> uniqueSpecializ =
        Set<String>(); // Create a set to store unique city names
    specializationSnapshot.docs.forEach((doc) {
      // Iterate over each document in the snapshot
      uniqueSpecializ
          .add(doc['docCategory'] as String); // Add the city name to the set
    });
    setState(() {
      _specializations = uniqueSpecializ.toList(); // Convert the set to a list
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Welcome Doctor"),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                color: Colors.blue,
                child: Row(
                  children: [
                    Expanded(
                      child: CustomTextField(
                        textController: _searchQueryController,
                        hint: "Search Doctor",
                        borderColor: Colors.white,
                        textColor: Colors.white,
                      ),
                    ),
                    10.widthBox,
                    DropdownButton<String?>(
                      value: _selectedCity,
                      onChanged: (value) {
                        setState(() {
                          _selectedCity = value;
                        });
                      },
                      items: _cities.map((city) {
                        return DropdownMenuItem(
                          value: city, // Make sure each city value is unique
                          child: Text(city),
                        );
                      }).toList(),
                    ),
                    DropdownButton<String?>(
                      value: _selectedSpecialization,
                      onChanged: (value) {
                        setState(() {
                          _selectedSpecialization = value;
                        });
                      },
                      items: _specializations.map((specialization) {
                        return DropdownMenuItem(
                          value:
                              specialization, // Make sure each specialization value is unique
                          child: Text(specialization),
                        );
                      }).toList(),
                    ),
                    10.widthBox,
                    IconButton(
                      onPressed: () {
                        Get.to(() => SearchView(
                              searchQuery:
                                  _searchQueryController.text.toLowerCase(),
                              city: _selectedCity ?? '',
                              specialization: _selectedSpecialization ?? '',
                            ));
                      },
                      icon: Icon(Icons.search),
                      color: Colors.white,
                    )
                  ],
                ),
              ),

              //... rest of your code
              20.heightBox,
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                      child: ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (BuildContext context, int index) {
                          return GestureDetector(
                            onTap: () {
                              Get.to(() => CategoryDetailsView(
                                  catName: iconTitleList[index]));
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              padding: const EdgeInsets.all(12),
                              margin: const EdgeInsets.only(right: 8),
                              child: Column(
                                children: [
                                  Image.asset(
                                    iconList[index],
                                    width: 30,
                                    color: Colors.white,
                                  ),
                                  5.heightBox,
                                  AppStyle.normal(
                                      title: iconTitleList[index],
                                      color: Colors.white),
                                ],
                              ),
                            ),
                          );
                        },
                        itemCount: 6,
                      ),
                    ),
                    10.heightBox,
                    Align(
                      alignment: Alignment.centerLeft,
                      child: AppStyle.bold(
                          title: "Popular Doctors",
                          color: Colors.blue,
                          size: AppSize.size18),
                    ),
                    20.heightBox,
                    FutureBuilder<QuerySnapshot>(
                        future: _controller.getDoctorList(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (!snapshot.hasData) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          } else {
                            var data = snapshot.data?.docs;

                            return SizedBox(
                              height: 150,
                              child: ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.horizontal,
                                itemCount: data?.length ?? 0,
                                itemBuilder: (BuildContext context, int index) {
                                  return GestureDetector(
                                    onTap: () {
                                      Get.to(() => DoctorProfileView(
                                            doc: data![index],
                                          ));
                                    },
                                    child: Container(
                                      clipBehavior: Clip.hardEdge,
                                      decoration: BoxDecoration(
                                        color: AppColors.bgDarkColor,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      margin: const EdgeInsets.only(right: 8),
                                      height: 100,
                                      width: 150,
                                      child: Column(
                                        children: [
                                          Container(
                                            width: 150,
                                            alignment: Alignment.center,
                                            color: Colors.blue,
                                            child: Image.asset(
                                              AppAssets.imgSignup,
                                              width: 100,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          5.heightBox,
                                          AppStyle.normal(
                                              title: data![index]['docName']),
                                          AppStyle.normal(
                                              title: data[index]['docCategory'],
                                              color: Colors.black54),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          }
                        }),
                    5.heightBox,
                    GestureDetector(
                      onTap: () {},
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: AppStyle.normal(
                            title: "View All", color: Colors.blue),
                      ),
                    ),
                    20.heightBox,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(
                        4,
                        (index) => Container(
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            children: [
                              Image.asset(
                                AppAssets.icBody,
                                width: 25,
                                color: Colors.white,
                              ),
                              5.heightBox,
                              AppStyle.normal(
                                  title: "Lap Test", color: Colors.white),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ));
  }
}

class SearchView extends StatelessWidget {
  final String searchQuery;
  final String city;
  final String specialization;

  SearchView({
    required this.searchQuery,
    required this.city,
    required this.specialization,
  });

  @override
  Widget build(BuildContext context) {
    Query query = FirebaseFirestore.instance.collection('doctors');

// Apply filters based on selected city and specialization
    if (city.isNotEmpty) {
      query = query.where('docAddress', isEqualTo: city);
    }
    if (specialization.isNotEmpty) {
      query = query.where('docCategory', isEqualTo: specialization);
    }

// Apply search query filter
    if (searchQuery.isNotEmpty) {
      String searchQueryLowerCase = searchQuery.toString().capitalized;
      query =
          query.where('docName', isGreaterThanOrEqualTo: searchQueryLowerCase);
      query = query.where('docName', isLessThan: '${searchQueryLowerCase}z');
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Search Results"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: query.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            var data = snapshot.data?.docs;

            if (data == null || data.isEmpty) {
              return Center(child: Text('No results found.'));
            }

            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(data[index]['docName']),
                  subtitle: Text(data[index]['docCategory']),
                  onTap: () {
                    // Handle tap action, such as navigating to doctor profile
                    Get.to(() => DoctorProfileView(
                          doc: data[index],
                        ));
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
