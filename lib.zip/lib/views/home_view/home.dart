import 'package:emart_app/views/appointment_view/appointment_view.dart';
import 'package:emart_app/views/category_view/category_view.dart';
import 'package:emart_app/views/doctor_views/doctor_home_view.dart';
import 'package:emart_app/views/home_view/doctor_home_view.dart';
import 'package:emart_app/views/home_view/home_view.dart';
import 'package:emart_app/views/settings_view/settings_view.dart';
import 'package:emart_app/views/user_appoinment_booked_views/user_booked_appointment.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  final bool isDoctor;

  const Home({Key? key, required this.isDoctor}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int selectedIndex = 0;
  List screenList = [
    HomeView(),
    const AppointmentView(),
    const CategoryView(),
    const SettingsView(),
  ];
  List DoctorList = [
    DoctorHomeScreen(),
    const UserBookedAppointmentScreen(),
    const CategoryView(),
    const SettingsView(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: !widget.isDoctor
          ? screenList.elementAt(selectedIndex)
          : DoctorList.elementAt(selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
          unselectedItemColor: Colors.white.withOpacity(0.5),
          selectedItemColor: Colors.white,
          selectedLabelStyle: const TextStyle(
            color: Colors.white,
          ),
          selectedIconTheme: const IconThemeData(
            color: Colors.white,
          ),
          unselectedLabelStyle: const TextStyle(
            color: Colors.blue,
          ),
          backgroundColor: Colors.blue,
          type: BottomNavigationBarType.fixed,
          currentIndex: selectedIndex,
          onTap: (value) {
            setState(() {
              selectedIndex = value;
            });
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            BottomNavigationBarItem(
                icon: Icon(Icons.book), label: "Appointment"),
            BottomNavigationBarItem(
                icon: Icon(Icons.category), label: "Category"),
            BottomNavigationBarItem(
                icon: Icon(Icons.settings), label: "Settings"),
          ]),
    );
  }
}
