import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/controllers/auth_controllers.dart';
import 'package:emart_app/res/components/custom_button.dart';
import 'package:emart_app/views/home_view/doctor_home_view.dart';
import 'package:emart_app/views/signup_view/signup_view.dart';
import 'package:get/get.dart';
import '../../res/components/custom_textfield.dart';
import '../home_view/home.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  var isDoctor = false;
  @override
  Widget build(BuildContext context) {
    var controller = Get.put(AuthController());
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.only(top: 40),
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 300,
                  child: Image.asset(
                    AppAssets.imgDoctor,
                    fit: BoxFit.fill,
                  ),
                ),
                10.heightBox,
                AppStyle.bold(
                    title: AppStrings.welcomeBack, size: AppSize.size18),
                AppStyle.bold(title: AppStrings.weAreExcited),
              ],
            ),
            30.heightBox,
            Expanded(
                child: Form(
                    child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomTextField(
                    hint: AppStrings.email,
                    textController: controller.emailController,
                  ),
                  10.heightBox,
                  CustomTextField(
                    hint: AppStrings.password,
                    textController: controller.passwordController,
                  ),
                  10.heightBox,
                  SwitchListTile(
                    value: isDoctor,
                    onChanged: (newValue) {
                      setState(() {
                        isDoctor = newValue;
                      });
                    },
                    title: "Sign in as a doctor".text.make(),
                  ),
                  20.heightBox,
                  Align(
                      alignment: Alignment.centerLeft,
                      child: AppStyle.normal(title: AppStrings.forgetPassword)),
                  20.heightBox,
                  CustomButton(
                    buttonText: AppStrings.login,
                    onTap: () {
                      Future.microtask(() {
                        controller.loginUser();
                        if (controller.userCredential != null) {
                          if (isDoctor) {
                            //signing as a doctor
                            Get.to(() => DoctorHomeView());
                          } else {
                            //signing as a user
                            Get.to(() => Home(isDoctor: isDoctor));
                          }
                        }
                      });
                    },
                  ),
                  20.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AppStyle.normal(title: AppStrings.dontHaveAccount),
                      8.widthBox,
                      GestureDetector(
                        onTap: () {
                          Get.to(() => const SignupView());
                        },
                        child: AppStyle.bold(title: AppStrings.signup),
                      )
                    ],
                  )
                ],
              ),
            )))
          ],
        ),
      ),
    );
  }
}
