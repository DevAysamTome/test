import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/res/components/waiting_screen.dart';
import 'package:emart_app/views/book_appointment_view/map_screen.dart';
import 'package:emart_app/views/doctor_views/doctor_home_view.dart';
import 'package:emart_app/views/home_view/home_view.dart';
import 'package:emart_app/views/signup_view/signup_view.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:firebase_core/firebase_core.dart';
import '../firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      theme: ThemeData(fontFamily: AppFonts.nunito),
      debugShowCheckedModeBanner: false,
      home: WaitingScreen(),
    );
  }
}
