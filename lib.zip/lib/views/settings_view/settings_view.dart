import 'package:emart_app/consts/consts.dart';
import 'package:emart_app/controllers/auth_controllers.dart';
import 'package:emart_app/controllers/settings_controller.dart';
import 'package:emart_app/lists.dart';
import 'package:emart_app/views/login_view/login_view.dart';
import 'package:get/get.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(SettingsController());
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: AppStyle.normal(
            title: "Settings", size: AppSize.size18, color: Colors.white),
      ),
      body: Obx(
        () => controller.isLoading.value
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Column(
                children: [
                  ListTile(
                    leading:
                        CircleAvatar(child: Image.asset(AppAssets.imgSignup)),
                    title: AppStyle.bold(title: controller.username.value),
                    subtitle: AppStyle.normal(title: controller.email.value),
                  ),
                  const Divider(),
                  10.heightBox,
                  ListView(
                    shrinkWrap: true,
                    children: List.generate(
                        settingsList.length,
                        (index) => ListTile(
                              onTap: () async {
                                if (index == 2) {
                                  AuthController().signout();
                                  Get.offAll(() => const LoginView());
                                }
                              },
                              leading: Icon(
                                settingsListIcons[index],
                                color: Colors.blue,
                              ),
                              title: AppStyle.bold(title: settingsList[index]),
                            )),
                  ),
                ],
              ),
      ),
    );
  }
}
