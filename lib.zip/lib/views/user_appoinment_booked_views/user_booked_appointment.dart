import 'package:emart_app/consts/consts.dart';
import 'package:flutter/material.dart';

class UserBookedAppointmentScreen extends StatelessWidget {
  const UserBookedAppointmentScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dummy list of booked appointments (replace it with your actual data)
    List<Map<String, dynamic>> bookedAppointments = [
      {
        "title": "Appointment 1",
        "doctorName": "Dr. John Doe",
        "date": "May 20, 2024",
        "time": "10:00 AM",
      },
      {
        "title": "Appointment 2",
        "doctorName": "Dr. Jane Smith",
        "date": "May 22, 2024",
        "time": "2:30 PM",
      },
      // Add more appointments as needed
    ];

    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          "المواعيد المحجوزة",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue, // Change the color as needed
      ),
      body: ListView.builder(
        itemCount: bookedAppointments.length,
        itemBuilder: (context, index) {
          final appointment = bookedAppointments[index];
          return Card(
            margin: EdgeInsets.all(10),
            elevation: 4,
            child: ListTile(
              title: Text(appointment["title"],
                  style: TextStyle(fontWeight: FontWeight.bold),
                  textDirection: TextDirection.rtl),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    "الطبيب: ${appointment["doctorName"]}",
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(height: 5),
                  Text("التاريخ: ${appointment["date"]}",
                      textDirection: TextDirection.rtl),
                  SizedBox(height: 5),
                  Text("الوقت: ${appointment["time"]}",
                      textDirection: TextDirection.rtl),
                ],
              ),
              onTap: () {
                // Add onTap functionality if needed
              },
            ),
          );
        },
      ),
    );
  }
}
